import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.schemas import CustomerData

EXAMPLE = CustomerData.model_config["json_schema_extra"]["example"]


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"


def test_predict(client):
    r = client.post("/predict", json=EXAMPLE)
    assert r.status_code == 200
    body = r.json()
    assert 0 <= body["churn_probability"] <= 1
    assert body["churn_prediction"] in (0, 1)


def test_missing_total_charges_is_handled(client):
    r = client.post("/predict", json={**EXAMPLE, "tenure": 0, "TotalCharges": None})
    assert r.status_code == 200


def test_invalid_category_rejected(client):
    assert client.post("/predict", json={**EXAMPLE, "Contract": "Weekly"}).status_code == 422


def test_batch(client):
    assert len(client.post("/predict/batch", json=[EXAMPLE, EXAMPLE]).json()) == 2
