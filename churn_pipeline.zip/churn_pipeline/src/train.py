"""Train, tune, evaluate and persist the churn model.

Run:  python -m src.train
"""
import json
import logging

import joblib
import matplotlib
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score, f1_score, precision_score, recall_score,
    roc_auc_score, precision_recall_curve, roc_curve,
)
from sklearn.model_selection import (
    GridSearchCV, StratifiedKFold, cross_val_predict, train_test_split,
)
from sklearn.pipeline import Pipeline

from src import config as cfg
from src.features import build_preprocessor, load_and_clean

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger("train")

MODEL_GRIDS = {
    "logistic_regression": (
        LogisticRegression(max_iter=2000, class_weight="balanced"),
        {"model__C": [0.01, 0.1, 1, 10]},
    ),
    "random_forest": (
        RandomForestClassifier(class_weight="balanced", random_state=cfg.RANDOM_STATE, n_jobs=-1),
        {"model__n_estimators": [200, 400], "model__max_depth": [6, 10, None],
         "model__min_samples_leaf": [5, 20]},
    ),
    "gradient_boosting": (
        GradientBoostingClassifier(random_state=cfg.RANDOM_STATE),
        {"model__n_estimators": [100, 200], "model__learning_rate": [0.05, 0.1],
         "model__max_depth": [2, 3]},
    ),
}


def net_benefit(y_true, proba, threshold: float) -> float:
    """Expected profit of a retention campaign that contacts everyone above `threshold`."""
    flagged = proba >= threshold
    saved = (flagged & (y_true == 1)).sum() * cfg.OFFER_SUCCESS_RATE * cfg.SAVED_VALUE
    cost = flagged.sum() * cfg.OFFER_COST
    return float(saved - cost)


def best_threshold(y_true, proba) -> tuple[float, float]:
    """Threshold that maximises campaign profit."""
    grid = np.linspace(0.05, 0.95, 91)
    profits = [net_benefit(y_true, proba, t) for t in grid]
    i = int(np.argmax(profits))
    return float(grid[i]), profits[i]


def tune(name, estimator, grid, X_train, y_train, cv):
    pipe = Pipeline([("prep", build_preprocessor()), ("model", estimator)])
    search = GridSearchCV(pipe, grid, scoring="roc_auc", cv=cv, n_jobs=-1, refit=True)
    search.fit(X_train, y_train)
    log.info("%-20s CV AUC=%.4f  params=%s", name, search.best_score_, search.best_params_)
    return search


def evaluate(y_true, proba, threshold) -> dict:
    pred = (proba >= threshold).astype(int)
    return {
        "roc_auc": roc_auc_score(y_true, proba),
        "pr_auc": average_precision_score(y_true, proba),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred),
        "f1": f1_score(y_true, pred),
        "threshold": threshold,
        "net_benefit": net_benefit(y_true, proba, threshold),
    }


def plot_curves(results, y_test):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    for name, r in results.items():
        fpr, tpr, _ = roc_curve(y_test, r["test_proba"])
        prec, rec, _ = precision_recall_curve(y_test, r["test_proba"])
        ax1.plot(fpr, tpr, label=f"{name} ({r['metrics']['roc_auc']:.3f})")
        ax2.plot(rec, prec, label=f"{name} ({r['metrics']['pr_auc']:.3f})")
    ax1.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax1.set(title="ROC curve", xlabel="False positive rate", ylabel="True positive rate")
    ax2.set(title="Precision-Recall curve", xlabel="Recall", ylabel="Precision")
    ax1.legend(); ax2.legend()
    fig.tight_layout()
    fig.savefig(cfg.REPORT_DIR / "model_curves.png", dpi=130)


def main():
    cfg.REPORT_DIR.mkdir(exist_ok=True)
    cfg.MODEL_PATH.parent.mkdir(exist_ok=True)

    X, y = load_and_clean(cfg.DATA_PATH)
    log.info("Loaded %d rows, churn rate %.1f%%", len(X), 100 * y.mean())
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=cfg.TEST_SIZE, stratify=y, random_state=cfg.RANDOM_STATE
    )
    cv = StratifiedKFold(cfg.CV_FOLDS, shuffle=True, random_state=cfg.RANDOM_STATE)

    results = {}
    for name, (estimator, grid) in MODEL_GRIDS.items():
        search = tune(name, estimator, grid, X_train, y_train, cv)
        # Threshold is picked on out-of-fold training predictions -> test set stays untouched.
        oof = cross_val_predict(search.best_estimator_, X_train, y_train, cv=cv,
                                method="predict_proba", n_jobs=-1)[:, 1]
        threshold, oof_profit = best_threshold(y_train.to_numpy(), oof)
        test_proba = search.predict_proba(X_test)[:, 1]
        results[name] = {
            "estimator": search.best_estimator_,
            "best_params": search.best_params_,
            "cv_auc": search.best_score_,
            "oof_profit_per_customer": oof_profit / len(y_train),
            "threshold": threshold,
            "test_proba": test_proba,
            "metrics": evaluate(y_test.to_numpy(), test_proba, threshold),
        }

    # Business-driven selection: highest expected campaign profit on out-of-fold data.
    best = max(results, key=lambda n: results[n]["oof_profit_per_customer"])
    log.info("Selected model: %s", best)

    plot_curves(results, y_test)
    summary = {
        "selected_model": best,
        "business_assumptions": {
            "offer_cost": cfg.OFFER_COST, "saved_value": cfg.SAVED_VALUE,
            "offer_success_rate": cfg.OFFER_SUCCESS_RATE,
        },
        "models": {
            n: {"best_params": r["best_params"], "cv_auc": r["cv_auc"],
                "oof_profit_per_customer": r["oof_profit_per_customer"],
                "test_metrics": r["metrics"]}
            for n, r in results.items()
        },
    }
    (cfg.REPORT_DIR / "metrics.json").write_text(json.dumps(summary, indent=2, default=float))

    for n, r in results.items():
        m = r["metrics"]
        log.info("%-20s AUC=%.3f PR-AUC=%.3f P=%.3f R=%.3f F1=%.3f thr=%.2f test profit=%.0f",
                 n, m["roc_auc"], m["pr_auc"], m["precision"], m["recall"], m["f1"],
                 m["threshold"], m["net_benefit"])

    joblib.dump(
        {"pipeline": results[best]["estimator"], "threshold": results[best]["threshold"],
         "model_name": best, "metrics": results[best]["metrics"]},
        cfg.MODEL_PATH,
    )
    log.info("Saved model to %s", cfg.MODEL_PATH)


if __name__ == "__main__":
    main()
