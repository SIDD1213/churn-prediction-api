"""Central configuration: paths, column groups and business assumptions."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "telco_churn.csv"
MODEL_PATH = ROOT / "models" / "churn_pipeline.joblib"
REPORT_DIR = ROOT / "reports"

TARGET = "Churn"
ID_COLUMN = "customerID"
RANDOM_STATE = 42
TEST_SIZE = 0.2
CV_FOLDS = 5

# Raw input columns (what the API receives).
RAW_NUMERIC = ["tenure", "MonthlyCharges", "TotalCharges"]
RAW_CATEGORICAL = [
    "gender", "SeniorCitizen", "Partner", "Dependents", "PhoneService",
    "MultipleLines", "InternetService", "OnlineSecurity", "OnlineBackup",
    "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
    "Contract", "PaperlessBilling", "PaymentMethod",
]
RAW_FEATURES = RAW_NUMERIC + RAW_CATEGORICAL

ADD_ON_SERVICES = [
    "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies",
]

# Business assumptions used to choose the model and decision threshold.
# Contacting a customer costs money; saving a churner earns value.
OFFER_COST = 20.0         # cost of a retention offer per flagged customer
SAVED_VALUE = 300.0       # revenue kept if a true churner is retained
OFFER_SUCCESS_RATE = 0.30  # share of true churners who accept the offer
