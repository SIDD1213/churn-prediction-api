"""Data cleaning, feature engineering and the preprocessing ColumnTransformer."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.config import ADD_ON_SERVICES, ID_COLUMN, RAW_CATEGORICAL, TARGET

TENURE_BINS = [-1, 12, 24, 48, 72, np.inf]
TENURE_LABELS = ["0-12m", "13-24m", "25-48m", "49-72m", "72m+"]


def load_and_clean(path) -> tuple[pd.DataFrame, pd.Series]:
    """Load the raw CSV, fix dtypes and return (X, y). Missing values stay as NaN
    so that imputation is fitted inside the pipeline (no train/test leakage)."""
    df = pd.read_csv(path)
    df = df.drop(columns=[ID_COLUMN], errors="ignore").drop_duplicates()
    # TotalCharges contains blank strings for brand-new customers.
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["SeniorCitizen"] = df["SeniorCitizen"].astype(str)
    y = (df.pop(TARGET).str.strip().str.lower() == "yes").astype(int)
    return df, y


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Adds derived features. Stateless, so it is safe to use inside CV."""

    def fit(self, X, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        X["SeniorCitizen"] = X["SeniorCitizen"].astype(str)
        total = pd.to_numeric(X["TotalCharges"], errors="coerce")

        # 1. Tenure group (categorical)
        X["tenure_group"] = pd.cut(
            X["tenure"], bins=TENURE_BINS, labels=TENURE_LABELS
        ).astype(str)
        # 2. Average monthly spend over the customer's lifetime
        X["avg_monthly_spend"] = total / X["tenure"].replace(0, np.nan)
        # 3. Number of add-on services subscribed
        X["num_addon_services"] = (X[ADD_ON_SERVICES] == "Yes").sum(axis=1)
        # 4. Recent price change vs lifetime average (price-hike signal)
        X["charge_delta"] = X["MonthlyCharges"] - X["avg_monthly_spend"]
        # 5. Customer has protective services that reduce churn risk
        X["has_protection"] = (
            (X["OnlineSecurity"] == "Yes") | (X["TechSupport"] == "Yes")
        ).astype(int)
        return X


NUMERIC_FEATURES = [
    "tenure", "MonthlyCharges", "TotalCharges",
    "avg_monthly_spend", "num_addon_services", "charge_delta", "has_protection",
]
CATEGORICAL_FEATURES = RAW_CATEGORICAL + ["tenure_group"]


def build_preprocessor() -> Pipeline:
    """Feature engineering -> impute -> scale numerics / one-hot encode categoricals."""
    numeric = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    columns = ColumnTransformer([
        ("num", numeric, NUMERIC_FEATURES),
        ("cat", categorical, CATEGORICAL_FEATURES),
    ])
    return Pipeline([("engineer", FeatureEngineer()), ("columns", columns)])
