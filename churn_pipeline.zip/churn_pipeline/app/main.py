"""FastAPI service exposing the trained churn model.

Run:  uvicorn app.main:app --reload     Docs: http://127.0.0.1:8000/docs
"""
from contextlib import asynccontextmanager

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException

from app.schemas import CustomerData, PredictionResponse
from src.config import MODEL_PATH, RAW_FEATURES

state: dict = {}


@asynccontextmanager
async def lifespan(_: FastAPI):
    if not MODEL_PATH.exists():
        raise RuntimeError(f"Model not found at {MODEL_PATH}. Run `python -m src.train` first.")
    state["bundle"] = joblib.load(MODEL_PATH)
    yield
    state.clear()


app = FastAPI(
    title="Customer Churn Prediction API",
    description="Returns churn probability and a binary prediction for a subscription customer.",
    version="1.0.0",
    lifespan=lifespan,
)


def _risk_level(p: float, threshold: float) -> str:
    if p >= max(threshold, 0.6):
        return "high"
    return "medium" if p >= threshold * 0.6 else "low"


def _score(customers: list[CustomerData]) -> list[PredictionResponse]:
    bundle = state["bundle"]
    frame = pd.DataFrame([c.model_dump() for c in customers])[RAW_FEATURES]
    try:
        probs = bundle["pipeline"].predict_proba(frame)[:, 1]
    except Exception as exc:  # pragma: no cover - defensive
        raise HTTPException(status_code=500, detail=f"Scoring failed: {exc}") from exc
    thr = bundle["threshold"]
    return [
        PredictionResponse(
            churn_probability=round(float(p), 4),
            churn_prediction=int(p >= thr),
            risk_level=_risk_level(float(p), thr),
            threshold=round(thr, 2),
            model=bundle["model_name"],
        )
        for p in probs
    ]


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok", "model": state["bundle"]["model_name"]}


@app.get("/model-info", tags=["meta"])
def model_info():
    b = state["bundle"]
    return {"model": b["model_name"], "threshold": b["threshold"], "test_metrics": b["metrics"]}


@app.post("/predict", response_model=PredictionResponse, tags=["prediction"])
def predict(customer: CustomerData):
    """Score a single customer."""
    return _score([customer])[0]


@app.post("/predict/batch", response_model=list[PredictionResponse], tags=["prediction"])
def predict_batch(customers: list[CustomerData]):
    """Score up to 1000 customers in one call."""
    if not 0 < len(customers) <= 1000:
        raise HTTPException(status_code=422, detail="Send between 1 and 1000 customers.")
    return _score(customers)
