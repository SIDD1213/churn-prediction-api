# Customer Churn Prediction Pipeline

End-to-end churn pipeline (Telco Customer Churn dataset): cleaning → feature engineering → 3 tuned models → business-driven model selection → FastAPI service.

## Quick start
```bash
pip install -r requirements.txt
python -m src.train                 # trains, tunes, evaluates, saves models/churn_pipeline.joblib
uvicorn app.main:app --reload       # API docs at http://127.0.0.1:8000/docs
pytest                              # API tests
```

## Pipeline
| Stage | Details |
|---|---|
| Cleaning | Drop ID/duplicates, blank `TotalCharges` → NaN, median/mode imputation **inside** the pipeline (no leakage) |
| Encoding | One-hot encoding (`handle_unknown="ignore"`) |
| New features | `tenure_group`, `avg_monthly_spend`, `num_addon_services`, `charge_delta`, `has_protection` |
| Scaling | `StandardScaler` on numeric features |
| Models | Logistic Regression, Random Forest, Gradient Boosting — `GridSearchCV`, 5-fold stratified, scoring = ROC-AUC |
| Metrics | ROC-AUC, PR-AUC, precision, recall, F1 (`reports/metrics.json`, `reports/model_curves.png`) |

## Business-based selection
Churners are a minority, so accuracy is misleading. Each model's decision threshold is chosen to maximise expected campaign profit:

`profit = (flagged churners × success rate × saved value) − (flagged customers × offer cost)`

Assumptions live in `src/config.py` (offer cost 20, saved value 300, success rate 30%). Thresholds and the winning model are chosen on **out-of-fold training predictions**, so the held-out test set is used only for final reporting.

## API
`POST /predict`
```json
{"gender":"Female","SeniorCitizen":0,"Partner":"Yes","Dependents":"No","tenure":5,
 "PhoneService":"Yes","MultipleLines":"No","InternetService":"Fiber optic",
 "OnlineSecurity":"No","OnlineBackup":"No","DeviceProtection":"No","TechSupport":"No",
 "StreamingTV":"Yes","StreamingMovies":"Yes","Contract":"Month-to-month",
 "PaperlessBilling":"Yes","PaymentMethod":"Electronic check",
 "MonthlyCharges":89.5,"TotalCharges":440.2}
```
Response:
```json
{"churn_probability":0.71,"churn_prediction":1,"risk_level":"high","threshold":0.21,"model":"gradient_boosting"}
```
Other endpoints: `POST /predict/batch`, `GET /health`, `GET /model-info`.

## Structure
```
src/config.py  src/features.py  src/train.py
app/main.py    app/schemas.py   tests/test_api.py
```
